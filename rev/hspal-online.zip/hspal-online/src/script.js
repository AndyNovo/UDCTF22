let DEBUG = true;

let parseSource = (source)=>{
  source=source.replace(/\n/g,"");
  let cmds = [];
  for(let i=0; i < source.length; i+=6){
    let nxt = source.substr(i,6);
    if (!nxt.match(/[0-9a-fA-F]{6}/)){
      return false;
    }
    cmds.push(nxt);
  }
  return cmds;
}

let register = 0;
let stacks = Array.from(Array(256), () => []);
let ops = [];
let symbols={};
let ip = -1;
let x = -1;
let y = -1;
let stepThrough = false;
let emergency = false;
let inputText = "";
let stack_guards = {
  2:1,3:1,18:1,19:1,65:1,66:1, 33:2,34:2,35:2,36:2,37:2,48:2,49:2,50:2,51:2,52:2,53:2
};

let displayData = ()=>{
  $("#debug").html(`ip: ${ip}<br> opcode: ${ops[ip]}<br> reg: ${register}<br> symbols: ${JSON.stringify(symbols)}<br> stacks: ${JSON.stringify(stacks)}<br>
opcodes: ${JSON.stringify(ops)}`);
  if (ip >= ops.length){
    $("#debug").prepend(`DONE`);
  }
}

let oneStep = ()=>{
    ip += 1;
  if (ip >= ops.length){
    emergency = true;
    return;
  }
  console.log(ip);
  let tmp = ops[ip];
  let op = parseInt(tmp.substr(0,2),16);
  let a = parseInt(tmp.substr(2,2),16);
  let b = parseInt(tmp.substr(4,2),16);
  let c = 256*a + b;
  
  if (stack_guards.hasOwnProperty(op)){
    let minvals = stack_guards[op];
    if (stacks[a].length < minvals){
      emergency = true;
      displayData();
      alert(`Error: ${op} needs ${minvals} elems`);
      return;
    }
  }
  
  switch (op){
    case 0x00:
      symbols[c] = ip;
      break;
    case 0x01:
      if (!symbols.hasOwnProperty(c)){
        emergency=true;
        displayData();
        alert("No such symbol");
        return;
      }
      ip=symbols[c];
      break;
    case 0x02:
      let tmp = stacks[a].pop();
      if (!symbols.hasOwnProperty(tmp)){
        emergency=true;
        displayData();
        alert("No such symbol");
        return;
      }
      ip=symbols[tmp];
      break;
    case 0x03:
      if (stacks[a].pop() > 0){
        ip += 1;
      }
      break;
    case 0x04:
      emergency = true;
      alert(`Halted with message ${c}`);
      return;
    case 0x10://IO stuff
      stacks[a].push(inputText.charCodeAt(0));
      inputText = inputText.substr(1);
      break;
    case 0x11://little cheeky here to read decimals between characters
      let numV = parseInt(inputText);
      stacks[a].push(numV & 0xffff);
      inputText = inputText.substr(numV.toFixed(0).length);
      break;
    case 0x12:
      $("#stdout").append(stacks[a].pop().toFixed(0));
      break;
    case 0x13:
      $("#stdout").append(String.fromCharCode(stacks[a].pop()));
      break;
    case 0x14:
      $("#stdout").append(
          stacks[a].map(nv=>String.fromCharCode(nv)).reverse().join("")
      );
      stacks[a]=[];
      break;
    case 0x20:
      register = c;
      break;
    case 0x21:
      x = stacks[a].pop();
      y = stacks[a].pop();
      stacks[a].push((x+y) & 0xffff);
      break;
    case 0x22:
      x = stacks[a].pop();
      y = stacks[a].pop();
      stacks[a].push((x-y));      
      break;
    case 0x23:
      x = stacks[a].pop();
      y = stacks[a].pop();
      stacks[a].push(x*y & 0xffff);
      break;
    case 0x24:
      x = stacks[a].pop();
      y = stacks[a].pop();
      stacks[a].push(Math.floor(x/y) & 0xffff);
      break;
    case 0x25:
      x = stacks[a].pop();
      y = stacks[a].pop();
      stacks[a].push((x**y) & 0xffff);
      break;
    case 0x26:
      register = Math.floor(Math.random()*c);
      break;
    case 0x30:
      x = stacks[a].pop();
      y = stacks[a].pop();
      stacks[b].push(x==y ? 1 : 0);
      break;
    case 0x31:
      x = stacks[a].pop();
      y = stacks[a].pop();
      stacks[b].push(x>y ? 1 : 0);
      break;
    case 0x32:
      x = stacks[a].pop();
      y = stacks[a].pop();
      stacks[b].push(x<y ? 1 : 0);
      break;
    case 0x33:
      x = stacks[a].pop();
      y = stacks[a].pop();
      stacks[b].push(x|y ? 1 : 0);
      break;
    case 0x34:
      x = stacks[a].pop();
      y = stacks[a].pop();
      stacks[b].push(x&y ? 1 : 0);
      break;
    case 0x35:
      x = stacks[a].pop();
      y = stacks[a].pop();
      stacks[b].push(x^y ? 1 : 0);
      break;
    case 0x36:
      stacks[a].push(register==0 ? 1 : 0);
      break;
    case 0x40:
      stacks[a].push(register);
      register=0;
      break;
    case 0x41:
      register = stacks[a].pop();
      break;
    case 0x42:
      register = stacks[a][stacks[a].length-1];
      break;
    case 0x43:
      register = stacks[a].length;
      break;
    default:
      emergency = true;
      alert("invalid op");
      displayData();
      return;
  }
  
  if (DEBUG){
    displayData();
  }
}

let startHSPAL = ()=>{
  let source = $("#source").val();
  let code = parseSource(source);
  if (!code){
    alert("invalid source");
    return;
  }
  localStorage.setItem("recentCode", JSON.stringify(source));
  register = 0;
  stacks = Array.from(Array(256), () => []);
  ops = code;
  symbols={};
  ip = -1;
  inputText = $("#stdin").val();
  localStorage.setItem("recentInput", inputText);
  emergency = false;
  $("#stdout").html('');
  if (!stepThrough){
    while (ip < ops.length && !emergency){
      oneStep();
    }
    ip = -1;
  } else {
    oneStep();
  }
};

let localCode = localStorage.getItem("recentCode");
if (!!localCode){
  $("#source").val(JSON.parse(localCode));
}

let localInput = localStorage.getItem("recentInput");
if (!!localInput){
  $("#stdin").val(localInput);
}

$("#runit").on("click",()=>{
  stepThrough = false;
  startHSPAL();
});

$("#step").on("click",()=>{
  stepThrough = true;
  if (ip == -1){
    startHSPAL();
  } else {
    oneStep();  
  }
});