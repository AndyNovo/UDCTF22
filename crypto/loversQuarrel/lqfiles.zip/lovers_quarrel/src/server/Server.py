import os
import flask
import uuid
import os
import typing
import functools
import logging

app = flask.Flask(__name__)
active_sessions: typing.Dict[uuid.UUID,"DHSession"] = {}

class NotPrimeException(Exception):
    pass

class Message(typing.NamedTuple):
    message: str
    iv: str
    def serialize(self)->typing.Dict[str,str]:
        return {"message": self.message, "iv": self.iv}
    def __repr__(self)->str:
        return str(self.serialize())

class DHSession(typing.NamedTuple):
    user: uuid.UUID
    exp: int
    messages: typing.List[Message]

def requires_session(handler):
    @functools.wraps(handler)
    def decorator(client: str, *args, **kwargs):
        client = uuid.UUID(client)
        if client in active_sessions.keys():
            return handler(client,*args,**kwargs)
        return flask.jsonify({"error": f"Client {client} has no active session!"}), 400
    return decorator

@app.route("/sessions/<client>",methods=["POST"])
def create_session(client: str):
    client = uuid.UUID(client)
    if client in active_sessions.keys():
        return flask.jsonify({"error": f"Client {client} already has an active session!"}), 400
    try:
        assert flask.request.is_json
        js = flask.request.json
        exp = js["exp"]
        active_sessions[client] = DHSession(client,exp,[])
    except AssertionError:
        return flask.jsonify({"error": "Content must be json data"}), 400
    except KeyError:
        return flask.jsonify({"error": "Missing requrired data"}), 400
    except NotPrimeException:
        return flask.jsonify({"error": "Modulus must be a prime number"}), 400
    logging.info(f"Started session for user {client}")
    return "", 201

@app.route("/sessions/<client>",methods=["DELETE"])
@requires_session
def delete_session(client: uuid.UUID):
    active_sessions.pop(client)
    logging.info(f"Finished session for user {client}")
    return "", 201

@app.route("/sessions/<client>/messages",methods=["POST"])
@requires_session
def add_message(client: uuid.UUID):
    try:
        assert flask.request.is_json
        message = Message(flask.request.json["message"],flask.request.json["iv"])
        logging.info(f"Added {message} to session for user {client}")
        active_sessions[client].messages.append(message)
    except AssertionError:
        return flask.jsonify({"error": "Request must come in JSON format!"}), 400
    except KeyError:
        return flask.jsonify({"error": "Body missing required \"message\" key!"}), 400
    return "", 201
    
@app.route("/sessions/<client>/key")
@requires_session
def get_key(client: uuid.UUID):
    logging.info(f"Returning key {hex(active_sessions[client].exp)}")
    return flask.jsonify({"exp": active_sessions[client].exp})

@app.route("/sessions/<client>/messages/<index>")
@requires_session
def get_message(client: uuid.UUID, index: str):
    try:
        i = int(index,10)
        assert i  >= 0
        message = active_sessions[client].messages[i]
        logging.info(f"Someone queried message {index}: {message}")
        return flask.jsonify(message.serialize())
    except (ValueError, AssertionError):
        return flask.jsonify({"error": "Expected valid positive base-10 number as index!"}), 400
    except IndexError:
        return flask.jsonify({"message": None})

if __name__ == "__main__":
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    app.run("::",5000)