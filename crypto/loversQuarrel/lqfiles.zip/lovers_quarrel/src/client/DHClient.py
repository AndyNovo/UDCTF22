import os
import time
import requests
import json
from Crypto.Util.Padding import pad, unpad
from Crypto.Cipher import AES
from Crypto.Util import number
import logging

class NoPartnerException(Exception):
    pass

class NoMessageException(Exception):
    pass

class DHSession(requests.Session):
    def __init__(self,id: str, g: int,s: int,p: int,partner: str,url: str, conversation_file: str, conversation_starter: bool):
        super(DHSession,self).__init__()
        self.shared_secret = None
        self.secret = s
        self.modulus = p
        self.exp = pow(g,self.secret,self.modulus)
        self.partner = partner
        self.id = id
        self.url = url
        self.conversation_starter = conversation_starter
        self.conversation_file = conversation_file
        self.__ctr = 0
        self.post(f"{url}/sessions/{self.id}",data=json.dumps({"exp": self.exp}),headers={"Content-Type": "application/json"})
        self.__get_key()

    def __get_key(self):
        for i in range(5):
            res = self.get(f"{self.url}/sessions/{self.partner}/key")
            if res.ok:
                self.shared_secret = pow(res.json()["exp"],self.secret,self.modulus).to_bytes(128,"big")[:16]
                return
            time.sleep(2**i)
        raise NoPartnerException("Partner is offline!")
    
    def __send_message(self,message: str):
        self.post(f"{self.url}/sessions/{self.id}/messages",data=self.__encrypt_and_serialize_message(message),headers={"Content-Type": "application/json"})

    def __read_message(self):
        res = self.get(f"{self.url}/sessions/{self.partner}/messages/{self.__ctr}")
        if res.ok and res.json()["message"]:
            self.__ctr += 1
            return res.json()
        else:
            raise NoMessageException()

    def __encrypt_and_serialize_message(self,message: str):
        cipher = AES.new(self.shared_secret,AES.MODE_CBC)
        ct = cipher.encrypt(pad(message.encode("utf-8"),16)).hex()
        return json.dumps({"message": ct, "iv": cipher.iv.hex()})

    def conversation(self):
        with open(self.conversation_file) as f:
            if self.conversation_starter:
                for line in f:
                    logging.debug(f"Sending {line.strip()}")
                    self.__send_message(line.strip())
                    self.wait_for_message()
            else:
                for line in f:
                    self.wait_for_message()
                    logging.debug(f"Sending {line.strip()}")
                    self.__send_message(line.strip())
    
    def wait_for_message(self):
        i = 0
        while i < 5:
            try:
                self.__read_message()
                return
            except NoMessageException:
                time.sleep(2**i)
                i += 1
        raise NoPartnerException()

    def end_conversation(self):
        self.delete(f"{self.url}/sessions/{self.partner}")

    def __exit__(self,*args):
        super(DHSession,self).__exit__(*args)
        self.end_conversation()

def dhsession(url: str, id: str, partner: str, g: int, s: int, p: int, conversation_file: str,conversation_starter: bool)->DHSession:
    return DHSession(id,g,s,p,partner,url,conversation_file,conversation_starter)

if __name__ == "__main__":
    g = 2
    s = number.getPrime(512)
    p = 0xf6c6d4d9e03b8d02e7a525366e6a811d8558fbde1368904742a82e376b2511b48108be0dddb3fbb8fefb22cd66e158ac684a98e09d122ce37cda9574f2fc62f6fb1b99d6663a8db8380391b35653b87991279b3a296a774d18ec18d42169ee67d4f21ba9b3f39cdced3a0584177aa6639a70f48622b719a4952ddb4decf3
    url = os.environ.get("MESSAGING_SERVER")
    partner = os.environ.get("PARTNER")
    id = os.environ.get("CHAT_ID")
    with dhsession(url,id,partner,g,s,p,os.environ.get("CONVERSATION"),os.environ.get("NAME") == "Eve") as session:
        session.conversation()


