#include <stdlib.h>
#include "aes.h"
#include <string.h>

void encrypt_block(uint8_t pt[16], uint8_t key[16], uint8_t iv[16]){
    struct AES_ctx keystruct;
    AES_init_ctx(&keystruct,key);
    uint8_t enciv[16];
    memcpy(enciv,iv,16*sizeof(uint8_t));
    AES_ECB_encrypt(&keystruct,enciv);
    for(int i = 0;i < 16;i++){
        pt[i] = pt[i] ^ enciv[i];
    }
}

size_t get_padded_length(size_t len){
    size_t output;
    if(len % 16){
        output = (len / 16) + 1;
    }else{
        output = len;
    }
    return output*16;
}

uint8_t *encrypt(char *pt, uint8_t key[16], uint8_t iv[16]){
    size_t desired_len = get_padded_length(strlen(pt));
    uint8_t *output = calloc(desired_len,sizeof(uint8_t));
    memcpy(output,pt,strlen(pt));
    #pragma omp parallel for firstprivate(iv) shared(key, pt, output)
    for(int i = 0;i < desired_len;i += 16){
        for(int j = 15;j > -1;j--){
            if(iv[j] < 255){
                #pragma omp atomic
                iv[j]+=(i/16);
                break;
            }else{
                iv[j] = 0;
            }
        }
        encrypt_block(output+i,key,iv);
    }
    return output;
}