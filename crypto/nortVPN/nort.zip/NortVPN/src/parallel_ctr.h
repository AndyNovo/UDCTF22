#include <stddef.h>
#include <stdint.h>
uint8_t *encrypt(char *,uint8_t[16],uint8_t[16]);
size_t get_padded_length(size_t);