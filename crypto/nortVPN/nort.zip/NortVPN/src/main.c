#include "parallel_ctr.h"
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>

#define MESSAGE_MAX 128

void print_hex(uint8_t *str, size_t len, FILE *output){
    for(int i = 0;i < len;i++){
        fprintf(output,"%02x",str[i]);
    }
    fprintf(output,"\n");
}

int main(int argc, char **argv){
    assert(argc == 4);
    FILE *keyfile = fopen(argv[1],"r");
    FILE *convo = fopen(argv[2],"r");
    FILE *enc = fopen(argv[3],"w");
    FILE *urandom = fopen("/dev/urandom","r");
    uint8_t key[16];
    fread(key,sizeof(uint8_t),16,keyfile);
    fclose(keyfile);
    char pt[MESSAGE_MAX+1];
    for(char *tmp = fgets(pt,MESSAGE_MAX,convo);tmp != NULL;tmp=fgets(pt,MESSAGE_MAX,convo)){
        size_t read_bytes = strlen(pt);
        if(pt[read_bytes-1] == '\n'){
            pt[read_bytes-1] = 0;
        }
        uint8_t iv[16];
        fread(iv,sizeof(uint8_t),8,urandom);
        memset(iv+8,0,8);
        fprintf(enc,"iv: ");
        print_hex(iv,16,enc);
        uint8_t *ct = encrypt(pt,key,iv);
        size_t len = get_padded_length(strlen(pt));
        fprintf(enc,"message: ");
        print_hex(ct,len,enc);
        free(ct);
    }
    fclose(convo);
    fclose(urandom);
    fclose(enc);
}